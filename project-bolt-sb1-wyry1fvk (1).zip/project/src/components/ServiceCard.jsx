import React from 'react';
import { motion } from 'framer-motion';
import ServiceList from './ServiceList';

export default function ServiceCard({ title, items, icon: Icon }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      whileHover={{ scale: 1.05 }}
      className="bg-white p-8 rounded-lg shadow-md"
    >
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
      >
        <Icon className="w-12 h-12 text-green-600 mb-6" />
      </motion.div>
      <h2 className="text-2xl font-bold mb-4">{title}</h2>
      <ServiceList items={items} />
    </motion.div>
  );
}
import React from 'react';
import { motion } from 'framer-motion';

const listItemVariants = {
  hidden: { opacity: 0, x: -20 },
  visible: i => ({
    opacity: 1,
    x: 0,
    transition: {
      delay: i * 0.1,
    },
  }),
};

export default function ServiceList({ items }) {
  return (
    <ul className="space-y-3 text-gray-600">
      {items.map((item, index) => (
        <motion.li
          key={index}
          custom={index}
          initial="hidden"
          animate="visible"
          variants={listItemVariants}
          className="flex items-center"
        >
          <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
          {item}
        </motion.li>
      ))}
    </ul>
  );
}
import React from 'react';
import ServiceCard from '../components/ServiceCard';
import { FaGraduationCap, FaMoneyBillWave, FaSchool, FaFileAlt } from 'react-icons/fa';

export default function StudentServices() {
  const services = [
    {
      title: "KUCCPS Applications",
      description: "Get assistance with your university and college placement applications through KUCCPS.",
      icon: FaGraduationCap
    },
    {
      title: "HELB Loan Applications",
      description: "We help you navigate the HELB loan application process for your education financing needs.",
      icon: FaMoneyBillWave
    },
    {
      title: "School Applications",
      description: "Comprehensive support for applying to various educational institutions across Kenya.",
      icon: FaSchool
    },
    {
      title: "Document Processing",
      description: "Assistance with academic documentation, transcripts, and certification processes.",
      icon: FaFileAlt
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-gray-900">Student Services</h1>
          <p className="mt-4 text-xl text-gray-600">Supporting your educational journey every step of the way</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <ServiceCard
              key={index}
              title={service.title}
              description={service.description}
              icon={service.icon}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import ServiceCard from '../components/ServiceCard';
import { FaIdCard, FaCalculator, FaGlobe, FaFileContract } from 'react-icons/fa';

export default function CitizenServices() {
  const services = [
    {
      title: "Huduma Services",
      description: "Access various government services through Huduma Centers with our guidance.",
      icon: FaIdCard
    },
    {
      title: "KRA Services",
      description: "Assistance with KRA PIN registration, returns filing, and tax compliance.",
      icon: FaCalculator
    },
    {
      title: "eCitizen Services",
      description: "Help with accessing and using various eCitizen portal services.",
      icon: FaGlobe
    },
    {
      title: "Documentation",
      description: "Support with government documentation and official paperwork.",
      icon: FaFileContract
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-gray-900">Citizen Services</h1>
          <p className="mt-4 text-xl text-gray-600">Making government services accessible and hassle-free</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <ServiceCard
              key={index}
              title={service.title}
              description={service.description}
              icon={service.icon}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import { FaGraduationCap, FaIdCard, FaUsers } from 'react-icons/fa';
import { motion } from 'framer-motion';
import heroBg from '../assets/hero-bg.jpg';
import AnimatedText from '../components/AnimatedText';
import ServiceCard from '../components/ServiceCard';

export default function Home() {
  const services = {
    student: {
      title: "Student Services",
      icon: FaGraduationCap,
      items: [
        "KUCCPS Applications",
        "HELB Loan Applications",
        "School Applications",
        "Academic Documentation"
      ]
    },
    citizen: {
      title: "Citizen Services",
      icon: FaIdCard,
      items: [
        "Huduma Services",
        "KRA Applications",
        "eCitizen Services",
        "Government Documentation"
      ]
    },
    benefits: {
      title: "Why Choose Us",
      icon: FaUsers,
      items: [
        "Affordable Rates",
        "Professional Assistance",
        "Quick Turnaround",
        "Experienced Team"
      ]
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="relative bg-green-700 text-white py-24">
        {/* Background Image */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
          className="absolute inset-0 z-0"
          style={{
            backgroundImage: `linear-gradient(rgba(22, 101, 52, 0.85), rgba(22, 101, 52, 0.85)), url(${heroBg})`,
            backgroundPosition: 'center',
            backgroundSize: 'cover',
            backgroundRepeat: 'no-repeat'
          }}
        />
        
        {/* Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <AnimatedText className="text-5xl font-bold mb-6 text-white">
              Welcome to NACHOSUN KE-NYA
            </AnimatedText>
            <AnimatedText 
              className="text-2xl text-white opacity-90"
              delay={0.3}
            >
              Your trusted partner for student and citizen services in Kenya
            </AnimatedText>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-8"
        >
          {Object.values(services).map((service, index) => (
            <ServiceCard
              key={index}
              title={service.title}
              items={service.items}
              icon={service.icon}
            />
          ))}
        </motion.div>
      </div>
    </div>
  );
}